Cortland Cast Server v0.6.2
==============================

This is the macOS (Apple Silicon) release of Cortland Cast Server.

Installation:
1. Extract this archive
2. Move "Cortland Cast Server.app" to your Applications folder
3. Launch the app

The server provides HTTP API endpoints for controlling Apple's Music app via Home Assistant.

For more information, visit: https://github.com/csilvertooth/cortland_cast

Version: 0.6.2
Built on: Thu Dec 11 15:06:44 MST 2025
