Cortland Cast Server v0.7.0
==============================

This is the macOS (Apple Silicon) release of Cortland Cast Server.

Installation:
1. Extract this archive
2. Move "Cortland Cast Server.app" to your Applications folder
3. Launch the app

The server provides HTTP API endpoints for controlling Apple's Music app via Home Assistant.

For more information, visit: https://github.com/csilvertooth/cortland_cast

Version: 0.7.0
Built on: Fri Dec 12 09:05:41 MST 2025
