Cortland Cast Server vv0.6.4
==============================

This is the macOS (Apple Silicon) release of Cortland Cast Server.

Installation:
1. Extract this archive
2. Move "Cortland Cast Server.app" to your Applications folder
3. Launch the app

The server provides HTTP API endpoints for controlling Apple's Music app via Home Assistant.

For more information, visit: https://github.com/csilvertooth/cortland_cast

Version: v0.6.4
Built on: Thu Dec 11 15:36:45 MST 2025
